// constructor is configured to create p5 buttons buttons

class MakeButton{
    constructor(_x, _y, _width, _height, _align_x, _align_y, _content,_pressedStuff){
        // this.x = _x
        // this.y = _y
        // this.width = _width
        // this.height= _height
        // this.align_x = _align_x
        // this.align_y = _align_y
        // this.content = _content
        this.element = new Button({
            x: _x,	y: _y,
            width: _width,		height: _height,
            align_x: _align_x,		align_y: _align_y,
            content: _content,
            on_press(){
                console.log(_pressedStuff)
            }
          });
          this.element.style('default',{"style.text_size":"25px"});
        
        
    }

// sends the built in draw command for p5 buttons 

// buttonPress(){
//     this.element.on_press()
//  }

drawCustomButton(){
    this.element.draw()
}

// I think? this should be all I need to do here, I have a template for the buttons
// and I can send the draw command with the drawcustombutton function

}